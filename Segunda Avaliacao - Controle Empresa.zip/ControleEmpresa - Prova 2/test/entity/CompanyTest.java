package entity;

import static org.junit.Assert.assertEquals;
import java.util.List;
 
import javax.persistence.EntityManager;
 
import org.junit.Test;
 
public class CompanyTest extends TestBase {
    
	private Company findCompanyNamed(final EntityManager em, String name) {
        return (Company) em.createQuery(
                "select c from Company c where c.name=?1")
                .setParameter(1, name).getSingleResult();
    }
	
    @Test
    public void createCompany() {
        final Company c1 = new Company();
        c1.setName("The Company");
        c1.setAddress(new Address("D Rd.", "", "Paris", "TX", "77382"));
 
        em.getTransaction().begin();
        em.persist(c1);
        em.getTransaction().commit();
 
        final Company foundCompany = findCompanyNamed(em, "The Company"); 
        assertEquals("D Rd.", foundCompany.getAddress().getStreetAddress1());
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void createCompanyAndHirePeople() {
        createCompanyWithTwoEmployees();
 
        final List<Person> list = em.createQuery("select p from Person p")
                .getResultList();
        assertEquals(2, list.size());
 
        final Company foundCompany = (Company) em.createQuery(
                "select c from Company c where c.name=?1").setParameter(1,
                "The Company").getSingleResult();
        assertEquals(2, foundCompany.getEmployees().size());
    }
 
    @Test
    public void hireTwoAndFireOne() {
    	//c1 est� "managed" (est� no contexto persistente)
        final Company c1 = createCompanyWithTwoEmployees();
        
        em.getTransaction().begin();
        c1.fire(c1.getEmployees().iterator().next());        
        em.getTransaction().commit();
        
        //limpa o contexto persistente
        em.clear();
 
        //busca do reposit�rio
        final Company foundCompany = findCompanyNamed(em, "The Company");
        assertEquals(1, foundCompany.getEmployees().size());
    }
    
    @Test
    public void changeCompanyName(){
    	//c1 est� "managed" (est� no contexto persistente)
        final Company c1 = createCompanyWithTwoEmployees();
                
        em.getTransaction().begin();
        c1.setName("New name");
        em.getTransaction().commit();
        
        //limpa o contexto persistente
        em.clear();
 
        //busca do reposit�rio
        findCompanyNamed(em, "New name");        
    }
    
    private Company createCompanyWithTwoEmployees() {
        final Company c1 = new Company();
        c1.setName("The Company");
        c1.setAddress(new Address("D Rd.", "", "Paris", "TX", "77382"));
 
        final List<Person> people = PersonTest.generatePersonObjects();
        for (Person p : people) {
            c1.hire(p);
        }
 
        em.getTransaction().begin();
        for (Person p : people) {
            em.persist(p);
        }
        em.persist(c1);
        em.getTransaction().commit();
 
        return c1;
    }
}