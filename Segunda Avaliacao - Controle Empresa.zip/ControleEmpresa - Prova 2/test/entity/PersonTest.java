package entity;
 
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNotNull;
 
import java.util.ArrayList;
import java.util.List;
 
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.junit.Test;
 
public class PersonTest extends TestBase {
    public static List<Person> generatePersonObjects() {
        final List<Person> people = new ArrayList<Person>();
        final Address a1 = new Address("A Rd.", "", "Dallas", "TX", "75001");
        final Person p1 = new Person("Brett", 'L', "Schuchert", a1);
 
        final Address a2 = new Address("B Rd.", "S2", "OkC", "OK", "73116");
        final Person p2 = new Person("FirstName", 'K', "LastName", a2);
 
        people.add(p1);
        people.add(p2);
 
        return people;
    }
 
    @SuppressWarnings("unchecked")
    @Test
    public void insertAndRetrieve() {
        final List<Person> people = generatePersonObjects();
 
        em.getTransaction().begin();
        for (Person p : people) {
            em.persist(p);
        }
        em.getTransaction().commit();        
        
        final List<Person> list = em.createQuery("select p from Person p")
                .getResultList();
 
        assertEquals(2, list.size());
        for (Person current : list) {
            final String firstName = current.getFirstName();
            final String streetAddress1 = current.getAddress()
                    .getStreetAddress1();
 
            assertTrue(firstName.equals("Brett") || firstName.equals("FirstName"));
            assertTrue(streetAddress1.equals("A Rd.") || streetAddress1.equals("B Rd."));
        }
    }
    
    @SuppressWarnings("unchecked")
    @Test
    public void insertAndRetrieveUsingHibernateAPI() {
        final List<Person> people = generatePersonObjects();
        
        Session session = (Session) em.getDelegate();
        Transaction tx = session.beginTransaction(); 

        for (Person p : people) {
            session.save(p);
        }
        tx.commit();
 
        //HQL query
        final List<Person> list = session.createQuery("from Person p").list();
        
        assertEquals(2, list.size());
        for (Person current : list) {
            final String firstName = current.getFirstName();
            final String streetAddress1 = current.getAddress()
                    .getStreetAddress1();
 
            assertTrue(firstName.equals("Brett") || firstName.equals("FirstName"));
            assertTrue(streetAddress1.equals("A Rd.") || streetAddress1.equals("B Rd."));
        }
        
        //Criteria Query
        Criteria criteria = session.createCriteria(Person.class);
        criteria.add(Restrictions.eq("firstName", "Brett"));
        Person p = (Person) criteria.uniqueResult();
        assertNotNull(p);
    }
}